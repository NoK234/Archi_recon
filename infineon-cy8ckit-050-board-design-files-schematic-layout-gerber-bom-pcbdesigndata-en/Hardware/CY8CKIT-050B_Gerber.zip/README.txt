These gerbers are in the RS-274X format.

--------------
 Gerber Files
--------------
art_param.txt          -- Gerber parameters for interpretation of RS274X layer data
PDC-9356_Fab.art       -- Printed Circuit Board fabrication notes
PDC-9356_TOP.art       -- Top etch layer 1
PDC-9356_BOTTOM.art    -- Bottom etch layer 4
PDC-9356_Tmask.art     -- Primary-side Solder Mask layer 1
PDC-9356_Tpaste.art    -- Primary-side Solder Paste layer 1
PDC-9356_Tsilk.art     -- Primary-side Silk Screen layer 1
PDC-9356_Bmask.art     -- Secondary-side Solder Mask layer4
PDC-9356_Bsilk.art     -- Secondary-side Silk Screen layer 4
PDC-9356_Power.art     -- Power Plane Layer 2
PDC-9356_Ground        -- Ground Plane Layer 3

----------------------------------------
 Drawings (PDF)
----------------------------------------
CY8CKIT-050B_Assembly.pdf      -- Primary-side &  Secondary-side Assembly drawing
CY8CKIT-050B_Board_Layout.pdf  -- Drill Drawing & Board Layers
-------------
 Drill Files
-------------
nc_param.txt                       -- Drill list parameters
CY8CKIT-050B_Board_Layout-1-4.drl  -- Tape File
ncdrill.log                        -- Drill list
slt_rep.rpt                        -- Slot Hole Report
----------------------
 Pick and Place Files
----------------------
CY8CKIT-050B-REVStarB-INSERT.txt -- Components list including pick-and-place locations



Instructions to view gerbers:

  GraphiCode, Inc. provides a freeware gerber viewer, GC-Prevue, available
  for download at te following URL:

  http://www.graphicode.com/pages/products.cfm#_Toc5 

  Once this application is installed you can view the *.art files by
  using the "File | Import" function. 

  Cypress uses a .art extension for gerber files. Gerber files are ASCII
  text and are easily identified to someone "learned in the art."